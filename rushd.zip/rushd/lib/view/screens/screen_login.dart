import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:rushd/view/screens/screen__registration.dart';

class ScreenLogin extends StatefulWidget {
  const ScreenLogin({Key? key}) : super(key: key);

  @override
  _ScreenLoginState createState() => _ScreenLoginState();
}

class _ScreenLoginState extends State<ScreenLogin> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
     body: SafeArea(
       child: Column(
         children: [
           Row(
             mainAxisAlignment: MainAxisAlignment.spaceBetween,
             children: [
               Row(
                 children: [
                   IconButton(onPressed: () {  },
                   icon: Icon(Icons.arrow_back)),
                   SizedBox(
                     width: 10,
                   ),
                   Text("Login",style: TextStyle(fontWeight: FontWeight.w800,fontSize: 18),),
                 ],
               ),

               Padding(
                 padding: const EdgeInsets.all(20.0),
                 child: Image.asset("assets/images/img.png",height: 80,width: 70,),
               ),
             ],
           ),
           SizedBox(
             height: 40,
           ),
           Align(
             alignment: Alignment.center,
               child: Text("Welcome Back !",style: TextStyle(fontSize: 18,fontWeight: FontWeight.w400),)),
           Padding(
             padding: const EdgeInsets.all(15.0),
             child: TextField(
               decoration: InputDecoration(
                   hintText: "Email",
                   filled: true,
                   fillColor: Colors.blue.withOpacity(0.22),
                   border: OutlineInputBorder(
                       borderSide: BorderSide(
                           width: 2
                       ),
                       borderRadius: BorderRadius.circular(12)
                   )
               ),
             ),
           ),
           Padding(
             padding: const EdgeInsets.all(15.0),
             child: TextField(
               decoration: InputDecoration(
                   hintText: "Password",
                   suffixIcon: Icon(Icons.remove_red_eye),
                   filled: true,
                   fillColor: Colors.blue.withOpacity(0.22),
                   border: OutlineInputBorder(
                       borderSide: BorderSide(
                           width: 2
                       ),
                       borderRadius: BorderRadius.circular(12)
                   )
               ),
             ),
           ),
           Padding(
             padding: const EdgeInsets.only(right: 15.0),
             child: Align(
               alignment: Alignment.bottomRight,
                 child: Text("Forget Password ?")),
           ),
           SizedBox(
             height: 30,
           ),
           OutlinedButton(onPressed: (){
             // Get.to(ScreenLogin());
           },
               style: OutlinedButton.styleFrom(
                 backgroundColor: Colors.blue,
                 padding: EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width*0.4,vertical: 15),

               )
               ,child: Text("Login",style: TextStyle(color: Colors.white),)),
           SizedBox(
             height: 15,
           ),
           Row(
             mainAxisAlignment: MainAxisAlignment.center,
             children: [
               Text("Don't have an account ?"),
               GestureDetector(
                 onTap: (){
                   Get.to(ScreenRegistration());
                 },
                   child: Text(" Sign Up",style: TextStyle(fontWeight: FontWeight.w600,fontSize: 18),)),
             ],
           ),
           SizedBox(
             height: 15,
           ),
           Image.asset("assets/images/img_3.png",width: 180,),
           SizedBox(
             height: 50,
           ),
           Row(
             mainAxisAlignment: MainAxisAlignment.spaceEvenly,
             children: [
               Image.asset("assets/images/img_3.png",width: 100,),
               Text("or Login with"),
               Image.asset("assets/images/img_3.png",width: 100,),
             ],
           ),
           SizedBox(
             height: 50,
           ),
           Image.asset("assets/images/img_4.png",height: 50,width: 50,),


         ],
       ),
     ),
    );
  }
}
