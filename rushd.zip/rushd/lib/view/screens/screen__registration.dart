import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:rushd/view/screens/screen_login.dart';

class ScreenRegistration extends StatefulWidget {
  const ScreenRegistration({Key? key}) : super(key: key);

  @override
  _ScreenRegistrationState createState() => _ScreenRegistrationState();
}

class _ScreenRegistrationState extends State<ScreenRegistration> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    IconButton(onPressed: () {
                      Get.offAll(ScreenLogin());
                    },
                        icon: Icon(Icons.arrow_back)),
                    SizedBox(
                      width: 10,
                    ),
                    Text("Registration",style: TextStyle(fontWeight: FontWeight.w800,fontSize: 18),),
                  ],
                ),

                Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Image.asset("assets/images/img.png",height: 80,width: 70,),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20.0),
              child: Align(
                  alignment: Alignment.topLeft,
                  child: Text("Students",style: TextStyle(fontSize: 18,fontWeight: FontWeight.w800),)),
            ),
            Stack(
              children: [
                Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.blue,
                  ),

                  child: Image.asset("assets/images/img_1.png",height: 120,width: 150,),
                ),
                Positioned(
                    right: 5,
                    bottom: 0,
                    child: Image.asset("assets/images/img_2.png",height: 50,width: 30,)),
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: TextField(
                decoration: InputDecoration(
                    hintText: "Full Name",
                    filled: true,
                    fillColor: Colors.blue.withOpacity(0.22),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(
                            width: 2
                        ),
                        borderRadius: BorderRadius.circular(12)
                    )
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: TextField(
                decoration: InputDecoration(
                    hintText: "User Name",
                    filled: true,
                    fillColor: Colors.blue.withOpacity(0.22),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(
                            width: 2
                        ),
                        borderRadius: BorderRadius.circular(12)
                    )
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: TextField(
                decoration: InputDecoration(
                    hintText: "Date of Birth",
                    suffixIcon: Icon(Icons.calendar_today,color: Colors.blue,),
                    filled: true,
                    fillColor: Colors.blue.withOpacity(0.22),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(
                            width: 2
                        ),
                        borderRadius: BorderRadius.circular(12)
                    )
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: TextField(
                decoration: InputDecoration(
                    hintText: "Email",
                    filled: true,
                    fillColor: Colors.blue.withOpacity(0.22),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(
                            width: 2
                        ),
                        borderRadius: BorderRadius.circular(12)
                    )
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: TextField(
                decoration: InputDecoration(
                    hintText: "Phone number",
                    filled: true,
                    fillColor: Colors.blue.withOpacity(0.22),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(
                            width: 2
                        ),
                        borderRadius: BorderRadius.circular(12)
                    )
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: TextField(
                decoration: InputDecoration(
                    hintText: "Gender",
                    suffixIcon: Icon(Icons.arrow_drop_down,color: Colors.blue,),
                    filled: true,
                    fillColor: Colors.blue.withOpacity(0.22),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(
                            width: 2
                        ),
                        borderRadius: BorderRadius.circular(12)
                    )
                ),
              ),
            ),
            OutlinedButton(onPressed: (){
              Get.to(ScreenLogin());
            },
                style: OutlinedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  padding: EdgeInsets.symmetric(horizontal: 50),

                )
                ,child: Text("Continue",style: TextStyle(color: Colors.white),)),


          ],
        ),
      ),
    );
  }
}
